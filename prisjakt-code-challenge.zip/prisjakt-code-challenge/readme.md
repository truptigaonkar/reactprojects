# Prisjakt code challenge

## Background
We have an engine collecting products that has dropped in price recently, exposed through a Deals API. This engine gives customers real-time feedback on price changes during large shopping events, like Black Friday and is used on all our campaigns. We also have an all year page called Daily Deals, that shows products found by our deal engine.

## Your mission
Our marketing team wants to keep up with the constant flow of products added to all markets. You mission is to create a simple dashboard where they can search for and look at product deals. They will use this dashboard when they want to investigate real-time trends during shopping events.

## Requirements
The tool must be web based. Its user interface should provide the ability to search for products by name and to see search results. There is a [wireframe mockup](./wireframe.png) attached, showcasing an example UI - but feel free to improvise. The code must include a readme file with instructions for us how to run it.

## Tools
- In [api.md](./api.md) you will find a description and a quick getting started guide with instructions how to query our Deals API. There are also example how to do different types of searches, aggregations and filters.
- In [product.json](./product.json) you will find and example with all data that is available for searching.

## What will we look at?
All aspects of the application; UI and UX, code quality, potential bugs, runtime performance. Your solution will be discussed during a potential next interview, so be prepared to motivate the technical decisions you made. Remeber that in a real project, you would be part of a team with all types of skills, so focus on what you are good at.

## Time
We expect that you need a couple of hours to create a functional application. If you want to spend more time, that is totally okay, but don’t overdo it!
