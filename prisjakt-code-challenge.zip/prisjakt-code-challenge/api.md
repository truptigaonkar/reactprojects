The search backend is an Elasticsearch index and you will query the backend directly.

### Available data
Check out the example data in [product.json](./product.json) to see what fields are available for searching and aggregation

### Endpoint
All queries are made as `POST` requests to the following endpoint: `https://search-pj-campaigns-dykc3wbnqz22xvoiwp2ta5bk3m.eu-west-1.es.amazonaws.com/campaign-*-4-deals/_search`

The `*` is used as wildcard to search in all markets

### Queries

POST one of the following examples:
```json
{
  "query": {
    "match": {
      "product.name": "apple"
    }
  }
}
```

For search-as-you-type functionality, use the `match_phrase_prefix` matcher
```json
{
  "query": {
    "match_phrase_prefix": {
      "product.name": "ap"
    }
  }
}
```

You can also search on multiple fields with a bool query
```json
{
  "query": {
    "bool": {
      "minimum_should_match": 1,
      "should": [
        {
          "match_phrase_prefix": {
            "product.name": {
              "query": "ap",
              "boost": 2
            }
          }
        },
        {
          "match_phrase_prefix": {
            "store.name": {
              "query": "ap",
              "boost": 2
            }
          }
        }
      ]
    }
  }
}
```

And add a filter for a specific category id

298 = Phones & GPS

```json
{
  "query": {
    "bool": {
      "minimum_should_match": 1,
      "should": [
        {
          "match_phrase_prefix": {
            "product.name": {
              "query": "ap",
              "boost": 2
            }
          }
        },
        {
          "match_phrase_prefix": {
            "store.name": {
              "query": "ap",
              "boost": 2
            }
          }
        }
      ],
      "must": [
        {
          "term": {
            "product.category.path.id": "298"
          }
        }
      ]
    }
  }
}
```

You can also aggregate data. For example count all products in top 20 categories.

```json
{
  "aggs": {
    "categories": {
      "terms": {
        "field": "product.category.path.id",
        "size": 20
      }
    }
  }
}
```

For more examples of queries, aggregations and filters. Check out the official Elastic documentation
- https://www.elastic.co/guide/en/elasticsearch/reference/5.5/query-dsl-match-query.html
- https://www.elastic.co/guide/en/elasticsearch/reference/5.5/search-aggregations.html
